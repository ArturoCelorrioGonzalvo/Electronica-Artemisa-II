import serial

# Configura el puerto serie y la velocidad de comunicación (baud rate)
ser = serial.Serial('COM3', 9600)  # Sustituye 'COM3' por el puerto de tu ESP32
file = open("datos.txt", "w")  # Crea el archivo datos.txt para escritura

print("Guardando datos en datos.txt. Pulsa Ctrl+C para detener.")

try:
    while True:
        # Lee una línea del puerto serie
        linea = ser.readline().decode('utf-8').strip()
        print(linea)  # Muestra la línea en la consola
        file.write(linea + '\n')  # Escribe la línea en el archivo
        file.flush()  # Asegura que los datos se guarden inmediatamente
except KeyboardInterrupt:
    print("\nDeteniendo el guardado de datos...")
finally:
    ser.close()  # Cierra el puerto serie
    file.close()  # Cierra el archivo